package tec;

interface Caractere {
    public void choixChangerPlace(Bus b, int arret, Passager p);
}

package tec;

interface Collecte{
    void uneEntree();
    void uneSortie();
    void changerArret();
}

package tec;

public interface Usager {
  public String nom();
  public void monterDans(Transport b) throws TecInvalidException;
}

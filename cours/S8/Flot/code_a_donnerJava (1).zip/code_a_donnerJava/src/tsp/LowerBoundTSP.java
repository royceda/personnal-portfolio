package tsp;

public class LowerBoundTSP{

    public double lowerBoundValue(double[][] matrix){
    	return 0.0;
    }

}